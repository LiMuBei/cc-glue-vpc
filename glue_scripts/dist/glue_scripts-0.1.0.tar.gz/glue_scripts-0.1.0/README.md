# Glue Jobs

This is the Python poetry project for the Glue jobs.

It contains a library which is built into a package, that the actual job scripts depend upon.